from django.contrib import admin
from .models import bbsreplay
# Register your models here.
admin.site.register(bbsreplay)
from django.db import models
from account.models import User
from topic.models import bbstopic
# Create your models here.
#回复
class bbsreplay(models.Model):
    RContent=models.TextField() #内容
    ReplyCreateTime=models.DateTimeField(auto_now_add=True) #回复创建时间
    ReplayLastTime=models.DateTimeField(auto_now=True)  #回复修改时间
    ReplayUser=models.ForeignKey(User,on_delete=models.CASCADE,related_name='user') #回复用户
    ReplayTopic=models.ForeignKey(bbstopic,on_delete=models.CASCADE) #回复帖子
    ReplayAttachment=models.CharField(max_length=50,null=True,error_messages={'unique':"A attachment with that Title already exists."}) #附件的名字
    def __str__(self):
        return self.RContent[0:10]
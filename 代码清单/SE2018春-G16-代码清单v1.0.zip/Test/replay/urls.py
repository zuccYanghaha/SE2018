from .views import postreplay
from django.conf.urls import url
urlpatterns = [
    url(r'^postreplay/(\d+)/$',postreplay,name='postreplay'),
]
import os
from django.shortcuts import render
from attachment.models import bbsattachment
from .models import bbsreplay
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib import auth
from topic.models import bbsplate,bbstopic
# Create your views here.

#回复
def postreplay(request,id):
    """
        功能：回复
        parm:(request)
        如果有上传的文件，获取上传文件
        导航栏基本年操作（查找，首页，登出，个人信息，登入/注册）
        @fym
    """
    if request.method=='POST':
        if 'posttopic' in request.POST:
            flag = 0
            myFile = request.FILES.get('myfile', None)  # 获取上传的文件，如果没有文件，则默认为None
            if myFile:
                destination = open(os.path.join("/home/upload", myFile.name),
                                   'wb+')  # 打开特定的文件进行二进制的写操作
                for chunk in myFile.chunks():  # 分块写入文件
                    destination.write(chunk)
                destination.close()
                flag = 1
            content = request.POST.get('content', '')
            user = request.user.id
            topicrs = bbstopic.objects.get(id=id)
            if(myFile != None):
                new_replay = bbsreplay.objects.create(RContent=content, ReplayUser_id=user, ReplayTopic_id=id,ReplayAttachment=myFile.name)
            else:
                new_replay = bbsreplay.objects.create(RContent=content, ReplayUser_id=user, ReplayTopic_id=id)
            if flag == 1:
                # 创建发帖的回复链接
                rs = bbsattachment.objects.create(AName=myFile, AFilePath="/home/upload",
                                                  ACreateReplay=new_replay, ACreateUser_id=request.user.id)
            return HttpResponseRedirect('/topic/detail/%s'%id)
        #导航栏
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    elif request.method=='GET':
        user=request.user.id
        plateid=bbstopic.objects.get(id=id).WherePlate_id
        topicrs=bbstopic.objects.get(id=id)
        result=bbsplate.objects.get(id=plateid)
        return render(request,'ReponseTopic-login.html',{'result':result,'topicrs':topicrs,'user':user})
    else:
        return HttpResponse("error")


from .views import show_topic,post_topic,bbs_detail,show_search,download,pretty_topic,download_replay
from django.conf.urls import url
urlpatterns = [
    url(r'^detail/(\d+)/$',bbs_detail,name='topicdetail'),
    url(r'posttopic/(\d+)/',post_topic,name='posttopic'),
    url(r'^topiclist/(\d+)/$', show_topic, name='topiclist'),
    url(r'^search/', show_search, name='search'),
    url(r'^download/(\d+)/',download, name='download'),
    url(r'^pretty/', pretty_topic, name='pretty'),
    url(r'^download_replay/(\d+)/', download_replay, name='download_replay'),
]
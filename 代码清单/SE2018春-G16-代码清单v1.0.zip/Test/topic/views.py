from django.shortcuts import render
from .models import bbstopic,whothum
from plate.models import bbsplate
from django.http import HttpResponseRedirect, HttpResponse, FileResponse
from django.urls import reverse
from django.db import  connection
from django.contrib import auth
from attachment.models import bbsattachment
import  os
# Create your views here.
def show_topic(request,id):
    """
        功能：显示帖子
        parm:(request，id)
        判断每个帖子是否有上传文件
        通过sql找到相应信息
        导航栏基本年操作（查找，首页，登出，个人信息，登入/注册）
        @fym
    """
    if request.method == 'GET':
        flagbutton=0
        flagbuttontime=0
        user=request.user
        bbs_topic_list=bbstopic.objects.filter(WherePlate=id)
        bbs_write=[]
        parma=(id)
        cursor=connection.cursor()
        cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id,a.WherePlate_id "
                       "from topic_bbstopic a,account_user b "
                       "where a.CreateUser_id=b.id and a.WherePlate_id="+parma+" order by a.SortOrder DESC")
        row=cursor.fetchall()
        result=bbsplate.objects.get(id=id)
        return render(request,'topicList-login.html',{'row':row,'user':user.id,'result':result,'flagbutton':flagbutton,'flagbuttontime':flagbuttontime})
    elif request.method == 'POST':
        if 'posttopic' in request.POST:
            user=request.user.id
            if user is None:
                return HttpResponseRedirect('/topic/topiclist/%s' % id)
            return HttpResponseRedirect('/topic/posttopic/%s' % id)
        elif 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        elif 'ordersupportd' in request.POST:
            user = request.user
            bbs_topic_list = bbstopic.objects.filter(WherePlate=id)
            bbs_write = []
            parma = (id)
            cursor = connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id,a.WherePlate_id "
                           "from topic_bbstopic a,account_user b "
                           "where a.CreateUser_id=b.id and a.WherePlate_id=" + parma + " order by a.TsupportCount DESC")
            row = cursor.fetchall()
            result = bbsplate.objects.get(id=id)
            flagbutton = 1;
            return render(request, 'topicList-login.html',
                          {'row': row, 'user': user.id, 'result': result, 'flagbutton': flagbutton})
        elif 'ordersupportup' in request.POST:
            user = request.user
            bbs_topic_list = bbstopic.objects.filter(WherePlate=id)
            bbs_write = []
            parma = (id)
            cursor = connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id,a.WherePlate_id "
                           "from topic_bbstopic a,account_user b "
                           "where a.CreateUser_id=b.id and a.WherePlate_id=" + parma + " order by a.TsupportCount")
            row = cursor.fetchall()
            result = bbsplate.objects.get(id=id)
            flagbutton = 0;
            return render(request, 'topicList-login.html',
                          {'row': row, 'user': user.id, 'result': result, 'flagbutton': flagbutton})
        elif 'ordertimed' in request.POST:
            user = request.user
            bbs_topic_list = bbstopic.objects.filter(WherePlate=id)
            bbs_write = []
            parma = (id)
            cursor = connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id,a.WherePlate_id "
                           "from topic_bbstopic a,account_user b "
                           "where a.CreateUser_id=b.id and a.WherePlate_id=" + parma + " order by a.TCreateTime DESC")
            row = cursor.fetchall()
            result = bbsplate.objects.get(id=id)
            flagbuttontime = 1
            return render(request, 'topicList-login.html',
                          {'row': row, 'user': user.id, 'result': result, 'flagbuttontime': flagbuttontime})
        elif 'ordertimeup' in request.POST:
            user = request.user
            bbs_topic_list = bbstopic.objects.filter(WherePlate=id)
            bbs_write = []
            parma = (id)
            cursor = connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id,a.WherePlate_id "
                           "from topic_bbstopic a,account_user b "
                           "where a.CreateUser_id=b.id and a.WherePlate_id=" + parma + " order by a.TCreateTime ")
            row = cursor.fetchall()
            result = bbsplate.objects.get(id=id)
            flagbuttontime = 0
            return render(request, 'topicList-login.html',
                          {'row': row, 'user': user.id, 'result': result, 'flagbuttontime': flagbuttontime})
        else:
            return HttpResponse("ERROR")

    else:
        return HttpResponse("ERROR")

def post_topic(request,id):
    """

        功能：发帖子
        parm:(request，id)
        发帖中先获取上传文件，然后创建发帖的回复链接。
        导航栏基本年操作（查找，首页，登出，个人信息，登入/注册）
        @fym
    """
    if request.method == 'GET':
        plate=bbsplate.objects.get(id=id)
        return render(request, 'postTopic-login.html',{'plate':plate})
    elif request.method == 'POST':
        if 'posttopic' in request.POST:
            flag=0
            myFile =request.FILES.get('myfile',None)    # 获取上传的文件，如果没有文件，则默认为None
            if  myFile:
                destination = open(os.path.join("/home/upload",myFile.name),'wb+')    # 打开特定的文件进行二进制的写操作
                for chunk in myFile.chunks():      # 分块写入文件
                    destination.write(chunk)
                destination.close()
                flag=1
            title = request.POST.get('post_title', '')
            content = request.POST.get('post_content','')
            check=None
            try:
                check=bbstopic.objects.get(TTitle=title)
            except:
                pass
            if check is not None:
                plate = bbsplate.objects.get(id=id)
                return render(request, 'postTopic-login.html', {'msg': '该帖子标题已存在', 'plate': plate})
            new_bbstopic = bbstopic.objects.create(TTitle=title,TContent=content,CreateUser_id=request.user.id,WherePlate_id=id,Isattachment=flag)
            if flag == 1:
                #创建发帖的回复链接
                rs=bbsattachment.objects.create(AName=myFile,AFilePath="/home/upload",ACreateTopic=new_bbstopic,ACreateUser_id=request.user.id)
            return HttpResponseRedirect('/topic/topiclist/%s' % id)
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")

def bbs_detail(request,bbs_id):
    """
        功能：帖子详情信息
        parm:(request，bbs_id)
        下载文件,删除置顶,增加置顶,删除加精,删除帖子,点赞,踩，回复
        对于非管理员而言没有删除置顶,增加置顶,删除加精,删除帖子功能。
        导航栏基本年操作（查找，首页，登出，个人信息，登入/注册）
        @fym&3y
    """
    if request.method=='GET':
        user=request.user
        if user.id is None:
            typename=-1
        else:
            typename=user.UserTypename
        bbs_detail=bbstopic.objects.get(id=bbs_id)
        cursor=connection.cursor()
        cursor.execute("select UID,ReplyCreateTime,Rcontent,ReplayAttachment,a.id "
                       "from replay_bbsreplay  a,account_user  b "
                       "where a.ReplayUser_id=b.id and a.ReplayTopic_id="+bbs_id+"")
        row=cursor.fetchall()
        plateid=bbs_detail.WherePlate_id
        plate=bbsplate.objects.get(id=plateid)
        # have_download 原来是否有下载的内容！
        bbs_download = bbsattachment.objects.filter(ACreateTopic=bbs_id)
        return render(request,'topicDetail-no.html',{'row':row,'bbs_detail':bbs_detail,'user':user.id,'plate':plate,'typename':typename,'have_download':bbs_download.count()})
    elif request.method=='POST':
        #下载文件
        if 'download' in request.POST:
            return HttpResponseRedirect(reverse(download))
        #删除置顶
        elif 'deletetop' in request.POST:
            bbs_detail=bbstopic.objects.get(id=bbs_id)
            bbs_detail.SortOrder=bbs_detail.SortOrder-2
            bbs_detail.save()
            return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
        #增加置顶
        elif'addtop' in request.POST:
            bbs_detail=bbstopic.objects.get(id=bbs_id)
            bbs_detail.SortOrder=bbs_detail.SortOrder+2
            bbs_detail.save()
            return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
        #删除加精
        elif 'deletesupport' in request.POST:
            bbs_detail=bbstopic.objects.get(id=bbs_id)
            bbs_detail.SortOrder=bbs_detail.SortOrder-1
            bbs_detail.save()
            return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
        #增加加精
        elif'addsupport' in request.POST:
            bbs_detail=bbstopic.objects.get(id=bbs_id)
            bbs_detail.SortOrder=bbs_detail.SortOrder+1
            bbs_detail.save()
            return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
        #删除帖子
        elif 'deletetopic'in request.POST:
            bbs_detail=bbstopic.objects.get(id=bbs_id)
            id=bbs_detail.WherePlate_id
            bbs_detail.delete()
            return HttpResponseRedirect('/topic/topiclist/%s' % id)
        #点赞
        elif 'goup' in request.POST:
            whoid=request.user.id
            if whoid is None:
                return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
            rs=None
            try:
                rs=whothum.objects.get(Whothrum=whoid,Wherethrum=bbs_id)
            except:
                pass

            if rs is None:
                bbs_detail=bbstopic.objects.get(id=bbs_id)
                bbs_detail.TsupportCount=bbs_detail.TsupportCount+1
                bbs_detail.save()
                rs=whothum.objects.create(Thrum_up=1,Whothrum_id=whoid,Wherethrum=bbs_id)
                return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
            else:
                if rs.Thrum_up == 0 and rs.Thrum_down == 0:
                    bbs_detail = bbstopic.objects.get(id=bbs_id)
                    bbs_detail.TsupportCount = bbs_detail.TsupportCount + 1
                    bbs_detail.save()
                    rs.Thrum_up = 1
                    rs.save()
                    return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
                elif rs.Thrum_up == 0 and rs.Thrum_down == 1:
                    bbs_detail = bbstopic.objects.get(id=bbs_id)
                    bbs_detail.TsupportCount = bbs_detail.TsupportCount + 1
                    bbs_detail.TdownCount = bbs_detail.TdownCount - 1
                    bbs_detail.save()
                    rs.Thrum_up = 1
                    rs.Thrum_down = 0
                    rs.save()
                    return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
                else:
                    return HttpResponseRedirect('/topic/detail/%s' % bbs_id)

        #踩
        elif 'godown' in request.POST:
            whoid=request.user.id
            if whoid is None:
                return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
            else:
                rs=None
                try:
                    rs=whothum.objects.get(Whothrum=whoid,Wherethrum=bbs_id)
                except:
                    pass
                if rs is None:
                    bbs_detail=bbstopic.objects.get(id=bbs_id)
                    bbs_detail.TdownCount=bbs_detail.TdownCount+1
                    bbs_detail.save()
                    result=whothum.objects.create(Thrum_down=1,Whothrum_id=whoid,Wherethrum=bbs_id)
                    return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
                else:
                    if rs.Thrum_down == 0 and rs.Thrum_up == 0:
                        bbs_detail = bbstopic.objects.get(id=bbs_id)
                        bbs_detail.TdownCount = bbs_detail.TdownCount + 1
                        bbs_detail.save()
                        rs.Thrum_down = 1
                        rs.save()
                        return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
                    elif rs.Thrum_down == 0 and rs.Thrum_up == 1:
                        bbs_detail = bbstopic.objects.get(id=bbs_id)
                        bbs_detail.TdownCount = bbs_detail.TdownCount + 1
                        bbs_detail.TsupportCount = bbs_detail.TsupportCount - 1
                        bbs_detail.save()
                        rs.Thrum_down = 1
                        rs.Thrum_up = 0
                        rs.save()
                        return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
                    else:
                        return HttpResponseRedirect('/topic/detail/%s' % bbs_id)

        #回复
        elif 'reponse' in request.POST:
            ruser=request.user.id
            if ruser is None:
                return HttpResponseRedirect('/topic/detail/%s' % bbs_id)
            else:
                return HttpResponseRedirect('/replay/postreplay/%s' % bbs_id)
        #导航栏按钮
        elif 'register_login' in request.POST:
            #   return render(request, '/account/register')
            return HttpResponseRedirect('/account/login/')  #####
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            #return HttpResponse("hello")
            return HttpResponseRedirect(reverse('index'))  #####
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    else:
        return HttpResponse("ERROR")

def show_search(request):
    """
        功能：搜索查询
        parm:(request)
        可以按照作者和标题按照模糊查询
        @fym
    """
    if request.method=='GET':
        user=request.user
        return render(request,'searchTopic-login.html',{'user':user.id})
    elif request.method=='POST':
        if 'search' in request.POST:
            seacrch_name=request.POST.get('search_name','')
            cursor=connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id "
                       "from topic_bbstopic a,account_user b "
                       "where a.CreateUser_id=b.id and TTitle like '"+"%"+seacrch_name+"%"+"' order by a.SortOrder DESC")
            row=cursor.fetchall()
            return render(request,'searchTopic-login.html',{'row':row})
        elif 'search_user'in request.POST:
            seacrch_name=request.POST.get('search_name','')
            cursor=connection.cursor()
            cursor.execute("select a.SortOrder,TTitle,TsupportCount,UID,TCreateTime,Isattachment,a.id "
                       "from topic_bbstopic a,account_user b "
                       "where a.CreateUser_id=b.id and b.UID like '"+"%"+seacrch_name+"%"+"'order by a.SortOrder DESC")
            row=cursor.fetchall()
            return render(request,'searchTopic-login.html',{'row':row})
        if 'register_login' in request.POST:
            #   return render(request, '/account/register')
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        else:
            return HttpResponse("ERROR")

    else:
        return HttpResponse("error")

def download(request,bbs_id):
    """
        功能：下载文件
        parm:(request，bbs_id)
        @3y
    """
    bbs_download = bbsattachment.objects.get(ACreateTopic_id=bbs_id).AName
    file = open("/home/upload/"+bbs_download, 'rb')
    pre_name = bbs_download.split('.')
    response = FileResponse(file)
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = "attachment;filename=\""+bbs_download+"\""
    return response

def download_replay(request,replay_id):
    """
        功能：下载（回复）
        parm:(request，replay_id)
        @3y
    """
    bbs_download = bbsattachment.objects.get(ACreateReplay_id=replay_id).AName
    file = open("/home/upload/"+bbs_download, 'rb')
    pre_name = bbs_download.split('.')
    response = FileResponse(file)
    response['Content-Type'] = 'application/octet-stream'
    #response['Content-Disposition'] = 'attachment;filename="xlsx_file.xlsx"'
    response['Content-Disposition'] = "attachment;filename=\""+bbs_download+"\""
    return response
def pretty_topic(request):
    """
        功能：精华板块
        parm:(request)
        对于所有的精华帖开设一个板块
        @fym
    """
    if request.method == 'GET':
        cursor=connection.cursor()
        user=request.user.id
        cursor.execute("select PlateName,TTitle,TsupportCount,UID,TCreateTime,isattachment, a.id "
                       "from topic_bbstopic a, plate_bbsplate b,account_user c "
                       "where a.WherePlate_id=b.id and a.CreateUser_id=c.id and (SortOrder ==1 or SortOrder == 3) order by b.id")
        row=cursor.fetchall()
        return render(request,'prettyTopic.html',{'row':row,'user':user})
    elif request.method=='POST':
        #导航栏
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    else:
        return HttpResponse("ERROR")


from django.contrib import admin
from .models import bbstopic
# Register your models here.
admin.site.register(bbstopic)
from .views import login,register,personally,change_password,forget_password
from django.conf.urls import url
urlpatterns = [

    url(r'^login/', login,name='login'),
    url(r'^register/',register,name='register'),
    url(r'^profile/',personally,name='proflie'),
    url(r'^changepassword/',change_password,name='change_password'),
    url(r'^forgetpassword/',forget_password,name='forgetpassword'),
]

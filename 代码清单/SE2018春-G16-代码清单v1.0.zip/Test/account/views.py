import json
import time
import random
from django.contrib import auth
from django.urls import reverse
from django.utils import timezone
from .models import User,Emailcode
from django.core.mail import  send_mail
#from django.contrib.auth.models import User
from account.models import User
from Test.settings import DEFAULT_FROM_EMAIL
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.hashers import check_password,make_password

def login(request):
    """
        登入表单类(username,pwd)
        如果信息正确：登入
        否则输出错误信息。
        @3y
    """
    if request.method=='POST':
        if 'login' in request.POST:
            uid=request.POST.get('UID','')
            upassword=request.POST.get('password','')
            user=auth.authenticate(username=uid,password=upassword)
            if user is not None :
                if user.is_active:
                    auth.login(request,user)
                    return HttpResponseRedirect(reverse('index'))
                else:
                    return render(request,'login-no.html',{'msg':'邮箱没有激活，请联系管理员'})
            else:
                return render(request,'login-no.html',{'msg':'账号密码不正确'})
        # 重置密码按钮
        elif 'forget_password' in request.POST:
            return HttpResponseRedirect(reverse('forgetpassword'))
        #注册界面跳转
        elif 'regist' in request.POST:
            return HttpResponseRedirect(reverse('register'))
        #页面导航栏按钮
        if 'register_login' in request.POST:
            #   return render(request, '/account/register')
            return HttpResponseRedirect('/account/login/')
        #搜索
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    elif request.method=='GET':
        return render(request,'login-no.html')
    else:
        return  HttpResponse("ERROR")

def send_send_mail(email):
    """
        功能：发邮件
        parm:(email)
        生成随机的6位验证码，发送注册的验证码。
        在数据库中记录。
        @3y
    """
    # 生成随机函数
    seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    sa = []
    for i in range(6):
        sa.append(random.choice(seed))
    checksum_post = ''.join(sa)

    email_info = Emailcode.objects.create(code=checksum_post, email=email)
    email_title = '恭喜您,成功加入zuccyanghaha.cn'
    email_body = '您好：\n'+ '    欢迎加入zuccyanghaha！\n'+'您的验证码是:'+ checksum_post +'\n此邮件为系统所发，请勿直接回复。\n'+'社区邮箱：shequ@yanghaha.cn\n'
    send_status = send_mail(email_title, email_body, DEFAULT_FROM_EMAIL, [email])
    return checksum_post

@csrf_exempt
def register(request):
    """
        功能：注册
        parm:(request)
        注册表单类（email, username, pwd1, pwd2）
        如果注册信息正确：
        写入数据库
        提示注册成功。
        否则：
            重新发送一张表单
        @3y
    """
    curtime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime());
    if request.method == 'POST':
        if request.is_ajax():
            code_code = ''
            #if 'send_check' in request.POST:
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')  # 邮箱
            code_code = send_send_mail(email)
            ret={"msg":"验证码发送成功!"}
            return HttpResponse(json.dumps(ret))
        elif 'registerbutton' in request.POST:
            nickname = request.POST.get('nickname', '')  # 用户名
            password = request.POST.get('password', '')
            repassword = request.POST.get('repassword', '')
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')
            check_get = request.POST.get('check_get', '')
            rs = User.objects.filter(UID=nickname)
            if len(nickname) > 20:
                return render(request, 'register-no.html', {'account_msg': '用户名不能超过20个字符'})
            elif nickname == "":
                return render(request, 'register-no.html', {'account_msg': '用户名不能为空'})
            elif len(rs) > 0:
                return render(request, 'register-no.html', {'account_msg': '账号已存在'})
            if password == "":
                return render(request, 'register-no.html', {'password_msg': '密码不能为空'})
            elif len(password) < 6 or len(password) > 20:
                return render(request, 'register-no.html', {'password_msg': '密码必须在6-20位'})
            if repassword == "":
                return render(request, 'register-no.html', {'repassword_msg': '密码不能为空'})
            elif len(repassword) < 6 or len(repassword) > 20:
                return render(request, 'register-no.html', {'repassword_msg': '密码必须在6-20位'})
            if password != repassword:
                return render(request, 'register-no.html', {'repassword_msg': '两次密码输入不一致'})
            rs = User.objects.filter(username=studyname)
            if len(rs) > 0:
                return render(request, 'register-no.html', {'studyname_msg': '学号已注册'})
            if check_get=="":
                return render(request, 'register-no.html', {'emaicode_msg': '验证码为空'})
            try:
                now_info = Emailcode.objects.get(code=check_get, email=email)
            except Emailcode.DoesNotExist:
                return render(request, 'register-no.html', {'emaicode_msg': '验证码错误'})
         #   if now_info == None:
         #       return render(request, 'register.html', {'studyname_msg': '验证码错误'})
            current_time = timezone.now()
            send_time = now_info.send_time
            past_time = current_time.timestamp() - send_time.timestamp()
            #15min
            if (past_time > 900):
                return render(request, 'register-no.html', {'emaicode_msg': '验证码过期'})
            user = User.objects.create_user(username=studyname, password=repassword, UID=nickname, email=email,
                                            UCreateTime=curtime)
            #注册成功
            return render(request, 'successRegister.html')
        #导航栏按钮
        if 'register_login' in request.POST:
            #   return render(request, '/account/register')
            return HttpResponseRedirect('/account/login/')  #####
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    elif request.method == 'GET':
        return render(request, 'register-no.html')
    else:
        return HttpResponse("ERROR")

def homepage(request):
    return  render_to_response('home-login.html')

def personally(request):
    """
        功能：查看个人信息
        parm:(request)
        输出参数：（username, userstudyname, useremail, usercreatetime，UserTypename）
        @3y
    """
    if request.method=='GET':
        user=request.user
        username=user.UID
        userstudyname=user.username
        useremail=user.email
        usercreatetime=user.UCreateTime
        return render(request,'profile-login.html',{'username':username,
                                               'userstudyname':userstudyname,
                                               'useremail':useremail,
                                               'usercreatetime':usercreatetime,
                                                'UserTypename':user.UserTypename,
                                               })
    elif request.method=='POST':
        if 'changepassword' in request.POST:
            return HttpResponseRedirect(reverse('change_password'))
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    else:
        return HttpResponse("ERROR")

def change_password(request):
    """
        功能：修改密码
        parm:(request)
        输出参数：（newpassword, oldpassword, renewpassword）
        @3y
    """
    if request.method=='POST':
        if 'allsure' in request.POST:
            newpassword=request.POST.get('newpassword','')
            oldpassword=request.POST.get('oldpassword','')
            renewpassword=request.POST.get('renewpassword','')
            user=request.user
            if user is None:
                return render(request,'changePassword.html',{'oldpassword_msg':'请先登录'})
            userpassword=user.password
            ps_bool=check_password(oldpassword,userpassword)
            if ps_bool==False:
                return render(request,'changePassword.html',{'oldpassword_msg':'旧密码不正确'})
            if newpassword!=renewpassword:
                return render(request,'changePassword.html',{'newpassword_msg':'两次密码输入不一致'})
            if newpassword=="":
                return render(request,'changePassword.html',{'newpassword_msg':'新密码不能为空'})
            if len(newpassword)<6 or len(newpassword)>20:
                return render(request,'changePassword.html',{'newpassword_msg':'新密码长度应该在6-20位之间'})
            if renewpassword=="":
                return render(request,'changePassword.html',{'renewpassword_msg':'重复新密码不能为空'})
            if len(renewpassword)<6 or len(renewpassword)>20:
                return render(request,'changePassword.html',{'renewpassword_msg':'重复新密码长度应该在6-20位之间'})
            user=User.objects.get(id=request.user.id)
            creatpassword=make_password(newpassword,None,'pbkdf2_sha256')
            user.password=creatpassword
            user.save()
            return HttpResponseRedirect(reverse('index'))
        #导航栏按钮
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            return HttpResponseRedirect(reverse('index'))
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    elif request.method=='GET':
        return render(request, 'changePassword.html')
    else:
        return HttpResponse("ERROR")

def send_send_mail_forget_password(email):
    """
        功能：忘记密码发送邮件
        parm:(email)
        @3y
    """
    # 生成随机函数
    seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    sa = []
    for i in range(6):
        sa.append(random.choice(seed))
    checksum_post = ''.join(sa)
    email_info = Emailcode.objects.create(code=checksum_post, email=email)
    email_title = '重置密码提示！'
    email_body = '您好：\n'+'您的验证码是:'+ checksum_post +'\n此邮件为系统所发，请勿直接回复。\n'+'社区邮箱：shequ@yanghaha.cn\n'
    send_status = send_mail(email_title, email_body, DEFAULT_FROM_EMAIL, [email])
    return checksum_post

def forget_password(request):
    """
        功能：忘记密码
        parm:(request)
        输出参数：（studyname, email）
        @3y
    """
    if request.method=='GET':
        return render(request,'forgetPassword-no.html')
    elif request.method=='POST':
        if request.is_ajax():
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')  # 邮箱
            code_code = send_send_mail_forget_password(email)
            ret = {"msg": "验证码发送成功!"}
            return HttpResponse(json.dumps(ret))
        if 'confirm' in request.POST:
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')
            check_get = request.POST.get('check_get', '')
            try:
                now_info = Emailcode.objects.get(code=check_get, email=email)
            except Emailcode.DoesNotExist:
                return render(request, 'forgetPassword-no.html', {'msg': '验证码错误'})
            current_time = timezone.now()
            send_time = now_info.send_time
            past_time = current_time.timestamp() - send_time.timestamp()
            # 15min
            if (past_time > 900):
                return render(request, 'forgetPassword-no.html', {'msg': '验证码过期'})
            #重置成功
            user = User.objects.get(email=email)
            createpassword=make_password(studyname,None,'pbkdf2_sha256')
            user.password=createpassword
            user.save()
            return render(request, 'successForgetPassword.html')
        #导航栏按钮
        if 'register_login' in request.POST:
            return HttpResponseRedirect('/account/login/')
        elif 'search' in request.POST:
            return HttpResponseRedirect(reverse('search'))
        else:
            return HttpResponse("ERROR")
    else:
        return HttpResponse("ERROR")




from django import forms
class RegisterForm(forms.ModelForm):
    password = forms.CharField(help_text='密码至少需要6位',
                               widget=forms.PasswordInput,
                               min_length=6,
                               required=True,
                               label="密码",
                               error_messages={
                                   'min_length': "密码过短",
                                   'require': "请输入密码"
                               })
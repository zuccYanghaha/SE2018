from django.contrib import admin
from .models import bbsplate
# Register your models here.

admin.site.register(bbsplate)
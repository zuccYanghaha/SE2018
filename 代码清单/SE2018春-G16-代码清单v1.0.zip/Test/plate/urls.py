from .views import study_life,entertainment_life
from django.conf.urls import url
urlpatterns = [

    url(r'^studylife/',study_life,name="study_life"),
url(r'^entertainmentlife/',entertainment_life,name="entertainment_life"),
]

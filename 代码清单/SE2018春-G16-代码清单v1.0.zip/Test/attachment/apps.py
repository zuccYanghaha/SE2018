from django.apps import AppConfig


class AttachmentConfig(AppConfig):
    name = 'attachment'

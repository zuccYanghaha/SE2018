from django.shortcuts import render,render_to_response
from django.template.context import RequestContext
from django.contrib.auth.models import User
from django.contrib import auth
from django.urls import reverse
from django.core.mail import  send_mail
from django.utils import timezone
import time
import random
from django.contrib.auth.hashers import check_password,make_password
import pdb
import json
from django.views.decorators.csrf import csrf_exempt
from Test.settings import DEFAULT_FROM_EMAIL
from .models import User,Emailcode
from django.http import HttpResponseRedirect, HttpResponse

def login(request):
    if request.method=='POST':
        if 'login' in request.POST:
            uid=request.POST.get('UID','')
            upassword=request.POST.get('password','')
            print(uid+''+upassword)
            user=auth.authenticate(username=uid,password=upassword)
            if user is not None :
                if user.is_active:
                    auth.login(request,user)
                    print(1)
                    # load_userdata_to_session(request,user.username)
                    # return HttpResponse("login success")
                    #return render_to_response('noticeRegister.html')
                    return HttpResponseRedirect(reverse('index'))  #####
                else:
                    print(2)
                    return render(request,'login-no.html',{'msg':'邮箱没有激活，请联系管理员'})
            else:
                print(3)
                return render(request,'login-no.html',{'msg':'账号密码不正确'})
                # return HttpResponse("账号密码不正确")
        # 重置密码按钮
        elif 'forget_password' in request.POST:
            return HttpResponseRedirect(reverse('forgetpassword'))  #####
        #注册界面跳转
        elif 'regist' in request.POST:
            return HttpResponseRedirect(reverse('register'))  #####
    elif request.method=='GET':
        print('login-get')
        return render(request,'login-no.html')
    else:
        return  HttpResponse("ERROR")

def send_send_mail(email):
    # 生成随机函数
    seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    sa = []
    for i in range(6):
        sa.append(random.choice(seed))
    checksum_post = ''.join(sa)
    print(checksum_post)
    print(email)
    email_info = Emailcode.objects.create(code=checksum_post, email=email)
    email_title = '恭喜您,成功加入zuccyanghaha.cn'
    email_body = '您好：\n'+ '    欢迎加入zuccyanghaha！\n'+'您的验证码是:'+ checksum_post +'\n此邮件为系统所发，请勿直接回复。\n'+'社区邮箱：shequ@yanghaha.cn\n'
    send_status = send_mail(email_title, email_body, DEFAULT_FROM_EMAIL, [email])
    if send_status:
        print("send!")
    print("YES")
    return checksum_post

@csrf_exempt
def register(request):
    curtime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime());
    print("post:")
    print(request.POST)
    print(request.is_ajax())
    print(request.method)
    if request.method == 'POST':
        print("pst!!!")
        print(request.is_ajax())
        if request.is_ajax():
            code_code = ''
            print("body:")
            print(request.body)
            #if 'send_check' in request.POST:
            studyname = request.POST.get('studyname', '')  # 学号
            print("tag:"+request.POST.get('domain', ''))
            email = studyname + request.POST.get('domain', '')  # 邮箱
            code_code = send_send_mail(email)
            ret={"msg":"验证码发送成功!"}
            return HttpResponse(json.dumps(ret))
            #return HttpResponseRedirect(reverse('register'))

        elif   'registerbutton' in request.POST:
            nickname = request.POST.get('nickname', '')  # 用户名
            password = request.POST.get('password', '')
            repassword = request.POST.get('repassword', '')
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')
            check_get = request.POST.get('check_get', '')
            rs = User.objects.filter(UID=nickname)
            if len(nickname) > 20:
                print(1)
                return render(request, 'register-no.html', {'account_msg': '用户名不能超过20个字符'})
            elif nickname == "":
                print(2)
                return render(request, 'register-no.html', {'account_msg': '用户名不能为空'})
            elif len(rs) > 0:
                print(3)
                return render(request, 'register-no.html', {'account_msg': '账号已存在'})
            if password == "":
                print(4)
                return render(request, 'register-no.html', {'password_msg': '密码不能为空'})
            elif len(password) < 6 or len(password) > 20:

                return render(request, 'register-no.html', {'password_msg': '密码必须在6-20位'})
            if repassword == "":
                print(6)
                return render(request, 'register-no.html', {'repassword_msg': '密码不能为空'})
            elif len(repassword) < 6 or len(repassword) > 20:
                print(7)
                return render(request, 'register-no.html', {'repassword_msg': '密码必须在6-20位'})
            if password != repassword:
                print(8)
                return render(request, 'register-no.html', {'repassword_msg': '两次密码输入不一致'})
            rs = User.objects.filter(username=studyname)
            if len(studyname) != 8:
                print(9)
                return render(request, 'register-no.html', {'studyname_msg': '学号输入不正确'})
            if len(rs) > 0:
                print(10)
                return render(request, 'register-no.html', {'studyname_msg': '学号已注册'})
            if check_get=="":
                return render(request, 'register-no.html', {'emaicode_msg': '验证码为空'})
            try:
                print('email='+email,'code='+check_get)
                now_info = Emailcode.objects.get(code=check_get, email=email)
            except Emailcode.DoesNotExist:
                print('mailcode')
                return render(request, 'register-no.html', {'emaicode_msg': '验证码错误'})
         #   if now_info == None:
         #       return render(request, 'register.html', {'studyname_msg': '验证码错误'})
            current_time = timezone.now()
            send_time = now_info.send_time
            past_time = current_time.timestamp() - send_time.timestamp()
            #15min
            if (past_time > 900):
                return render(request, 'register-no.html', {'emaicode_msg': '验证码过期'})
            user = User.objects.create_user(username=studyname, password=repassword, UID=nickname, email=email,
                                            UCreateTime=curtime)

            #注册成功
            print(11)
            return render(request, 'successRegister.html')

    elif request.method == 'GET':
        print(12)
        return render(request, 'register-no.html')
    else:
        print(13)
        return HttpResponse("ERROR")

def homepage(request):
    return  render_to_response('home-login.html')


def personally(request):
    if request.method=='GET':
        user=request.user
        username=user.UID
        userstudyname=user.username
        useremail=user.email
        usercreatetime=user.UCreateTime
        return render(request,'profile-login.html',{'username':username,
                                               'userstudyname':userstudyname,
                                               'useremail':useremail,
                                               'usercreatetime':usercreatetime,
                                               })
    elif request.method=='POST':
        if 'changepassword' in request.POST:
            print("changepassword")
            return HttpResponseRedirect(reverse('change_password'))
    else:
        return HttpResponse("ERROR")

def change_password(request):
    if request.method=='POST':
        if 'allsure' in request.POST:
            newpassword=request.POST.get('newpassword','')
            oldpassword=request.POST.get('oldpassword','')
            renewpassword=request.POST.get('renewpassword','')
            user=request.user
            if user is None:
                return render(request,'changePassword.html',{'oldpassword_msg':'请先登录'})
            userpassword=user.password
            print(newpassword)
            print(oldpassword)
            print(renewpassword)
            print(userpassword)
            ps_bool=check_password(oldpassword,userpassword)
            if ps_bool==False:
                return render(request,'changePassword.html',{'oldpassword_msg':'旧密码不正确'})
            if newpassword!=renewpassword:
                return render(request,'changePassword.html',{'newpassword_msg':'两次密码输入不一致'})
            if newpassword=="":
                return render(request,'changePassword.html',{'newpassword_msg':'新密码不能为空'})
            if len(newpassword)<6 or len(newpassword)>20:
                return render(request,'changePassword.html',{'newpassword_msg':'新密码长度应该在6-20位之间'})
            if renewpassword=="":
                return render(request,'changePassword.html',{'renewpassword_msg':'重复新密码不能为空'})
            if len(renewpassword)<6 or len(renewpassword)>20:
                return render(request,'changePassword.html',{'renewpassword_msg':'重复新密码长度应该在6-20位之间'})
            print(100)
            user=User.objects.get(id=request.user.id)
            creatpassword=make_password(newpassword,None,'pbkdf2_sha256')
            user.password=creatpassword
            user.save()
            print('success')
            return HttpResponseRedirect(reverse('index'))  #####

        else:
            return render(request, 'changePassword.html')
    elif request.method=='GET':
        print('wsdx')
        return render(request, 'changePassword.html')
    else:
        return HttpResponse("ERROR")

def send_send_mail_forget_password(email):
    # 生成随机函数
    seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    sa = []
    for i in range(6):
        sa.append(random.choice(seed))
    checksum_post = ''.join(sa)
    print(checksum_post)
    print(email)
    email_info = Emailcode.objects.create(code=checksum_post, email=email)
    email_title = '重置密码提示！'
    email_body = '您好：\n'+'您的验证码是:'+ checksum_post +'\n此邮件为系统所发，请勿直接回复。\n'+'社区邮箱：shequ@yanghaha.cn\n'
    send_status = send_mail(email_title, email_body, DEFAULT_FROM_EMAIL, [email])
    if send_status:
        print("send!")
    print("YES")
    return checksum_post

def forget_password(request):
    if request.method=='GET':
        return render(request,'forgetPassword-no.html')
    elif request.method=='POST':
        print(request.is_ajax())
        if request.is_ajax():
            print("body:")
            print(request.body)
            studyname = request.POST.get('studyname', '')  # 学号
            print("tag:" + request.POST.get('domain', ''))
            email = studyname + request.POST.get('domain', '')  # 邮箱
            code_code = send_send_mail_forget_password(email)
            ret = {"msg": "验证码发送成功!"}
            return HttpResponse(json.dumps(ret))
        if 'confirm' in request.POST:
            print("confirm")
            studyname = request.POST.get('studyname', '')  # 学号
            email = studyname + request.POST.get('domain', '')
            check_get = request.POST.get('check_get', '')
            try:
                print('email=' + email, 'code=' + check_get)
                now_info = Emailcode.objects.get(code=check_get, email=email)
            except Emailcode.DoesNotExist:
                print('mailcode')
                return render(request, 'successForgetPassword.html', {'msg': '验证码错误'})
            current_time = timezone.now()
            send_time = now_info.send_time
            past_time = current_time.timestamp() - send_time.timestamp()
            # 15min
            if (past_time > 900):
                return render(request, 'successForgetPassword.html', {'msg': '验证码过期'})
            #重置成功
            print(11)
            user = User.objects.get(email=email)
            print(user)
            createpassword=make_password(studyname,None,'pbkdf2_sha256')
            user.password=createpassword
            user.save()
            print("change_success")
            return render(request, 'successForgetPassword.html')
    else:
        return HttpResponse("ERROR")




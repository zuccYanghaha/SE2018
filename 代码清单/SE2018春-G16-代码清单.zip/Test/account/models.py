from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
class User(AbstractUser): #用户model
    UID=models.CharField(max_length=150,unique=True,error_messages={'unique':"A user with that username already exists."})  #昵称
    UserProfilePicture=models.ImageField(blank=True,default='/static/image/default.jpg') #用户头像
    UCreateTime=models.DateTimeField(auto_now_add=True)#创建时间
    UserTypename=models.IntegerField(default=0) #用户类别：1代表普通用户，2代表论坛管理员，3代表开法人员
    def __str__(self): #查询的时候
        return self.UID
class Emailcode(models.Model): #邮箱验证
    code=models.CharField(max_length=20) #验证码
    email=models.EmailField(max_length=50) #邮箱
    send_time=models.DateTimeField(auto_now=True) #发送时间
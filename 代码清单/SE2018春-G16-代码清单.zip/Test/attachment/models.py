from django.db import models
from account.models import User
from topic.models import bbstopic
from replay.models import bbsreplay
# Create your models here.
class bbsattachment(models.Model): #附件
    AName=models.CharField(max_length=50,unique=True,error_messages={'unique':"A attachment with that Title already exists."}) #附件名称
    AFilePath=models.CharField(max_length=300) #附件路径
    ACreateTime=models.DateTimeField(auto_now_add=True) #附件上传时间
    ACreateUser=models.ForeignKey(User,null=True,on_delete=models.SET_NULL) #附件上传者
    ACreateTopic=models.ForeignKey(bbstopic,on_delete=models.CASCADE) #附件所在帖子
    def __str__(self):
        return  self.AName

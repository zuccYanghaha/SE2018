from django.contrib import admin
from django.urls import path
from .views import study_life,entertainment_life
from account.views import login
from django.conf.urls import url
urlpatterns = [
    # Examples:
    # url(r'^$', 'PostParams.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^studylife/',study_life,name="study_life"),
url(r'^entertainmentlife/',entertainment_life,name="entertainment_life"),
]

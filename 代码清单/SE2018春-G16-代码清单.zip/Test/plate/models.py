from django.db import models
class bbsplate(models.Model): #板块
    PlateName=models.CharField(max_length=50,unique=True,error_messages={'unique':"A plate with that PlateName already exists."})#板块名称
    PlateIntro=models.TextField() #板块介绍
    PlateType=models.IntegerField(default=0)  #板块分类
    PlateIsHome=models.IntegerField(default=0) #板块是否到首页
    PlateCreateTime=models.DateTimeField(auto_now_add=True) #板块创建时间
    # PlateCreateUser=models.ForeignKey(User,on_delete=models.SET_NULL) #板块创建者
    def __str__(self):
        return  self.PlateName
from django.shortcuts import render
from plate.models import bbsplate
from topic.models import bbstopic
from django.shortcuts import render,render_to_response,reverse,HttpResponse
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib import auth
# Create your views here.
def home_deal(request):
    if request.method=='GET':
        bbs_plate_list=bbsplate.objects.filter(PlateIsHome=1)
        print(12)
        user = request.user
        print(user.id)
        print(user.username)
        print(user)
        bbs_topic_first_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[0].id,TopicISHome=1)
        print(24)
        bbs_topic_second_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[1].id,TopicISHome=1)
        bbs_topic_third_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[2].id,TopicISHome=1)
        bbs_topic_fouth_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[3].id,TopicISHome=1)
        bbs_topic_fifth_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[4].id,TopicISHome=1)
        bbs_topic_sixth_list=bbstopic.objects.filter(WhereClass_id=bbs_plate_list[5].id,TopicISHome=1)
        return render(request, 'home-no.html', {'bbs_plate_first_list': bbs_plate_list[0].PlateName,
                                                'bbs_plate_second_list': bbs_plate_list[1].PlateName,
                                                'bbs_plate_third_list': bbs_plate_list[2].PlateName,
                                                'bbs_plate_fouth_list': bbs_plate_list[3].PlateName,
                                                'bbs_plate_fifth_list': bbs_plate_list[4].PlateName,
                                                'bbs_plate_sixth_list': bbs_plate_list[5].PlateName,
                                                'bbs_plate_first_list_id': bbs_plate_list[0].id,
                                                'bbs_plate_second_list_id': bbs_plate_list[1].id,
                                                'bbs_plate_third_list_id': bbs_plate_list[2].id,
                                                'bbs_plate_fouth_list_id': bbs_plate_list[3].id,
                                                'bbs_plate_fifth_list_id': bbs_plate_list[4].id,
                                                'bbs_plate_sixth_list_id': bbs_plate_list[5].id,
                                                'bbs_topic_first_list': bbs_topic_first_list,
                                                'bbs_topic_second_list': bbs_topic_second_list,
                                                'bbs_topic_third_list': bbs_topic_third_list,
                                                'bbs_topic_fouth_list': bbs_topic_fouth_list,
                                                'bbs_topic_fifth_list': bbs_topic_fifth_list,
                                                'bbs_topic_sixth_list': bbs_topic_sixth_list,
                                                'user': user.id,
                                                })

    elif request.method == 'POST':
        print(12)
        if 'register_login' in request.POST:
         #   return render(request, '/account/register')
            return HttpResponseRedirect('/account/login/')  #####
        elif 'loginout' in request.POST:
            auth.logout(request)
            user = request.user
            #return HttpResponse("hello")
            return HttpResponseRedirect(reverse('index'))  #####
        elif 'personal_info' in request.POST:
            return HttpResponseRedirect(reverse('proflie'))
        else:
            print(13)
            return HttpResponse("ERROR")

def study_life(request):
    if request.method=='GET':
        plate_list=bbsplate.objects.filter(PlateType=0)
        plate_first_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[0].id,TopicISHome=1)
        plate_second_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[1].id,TopicISHome=1)
        plate_third_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[2].id,TopicISHome=1)
        return render(request,'studyLife-login.html',{'bbs_plate_first_list':plate_list[0].PlateName,
                                                'bbs_plate_second_list':plate_list[1].PlateName,
                                                'bbs_plate_third_list':plate_list[2].PlateName,
                                                'bbs_plate_first_list_id':plate_list[0].id,
                                                'bbs_plate_second_list_id':plate_list[1].id,
                                                'bbs_plate_third_list_id':plate_list[2].id,
                                                'plate_first_topic_list':plate_first_topic_list,
                                                'plate_second_topic_list':plate_second_topic_list,
                                                'plate_third_topic_list':plate_third_topic_list,
                                                })
    elif request.method=='GET':
        return render(request,'studyLife-login.html')
    else:
        return HttpResponse("error")


def entertainment_life(request):
    if request.method=='GET':
        plate_list=bbsplate.objects.filter(PlateType=1)
        plate_first_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[0].id,TopicISHome=1)
        plate_second_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[1].id,TopicISHome=1)
        plate_third_topic_list=bbstopic.objects.filter(WhereClass_id=plate_list[2].id,TopicISHome=1)
        return render(request,'entertainmentlife.html',{'bbs_plate_first_list':plate_list[0].PlateName,
                                                      'bbs_plate_second_list':plate_list[1].PlateName,
                                                      'bbs_plate_third_list':plate_list[2].PlateName,
                                                      'bbs_plate_first_list_id':plate_list[0].id,
                                                      'bbs_plate_second_list_id':plate_list[1].id,
                                                      'bbs_plate_third_list_id':plate_list[2].id,
                                                      'plate_first_topic_list':plate_first_topic_list,
                                                      'plate_second_topic_list':plate_second_topic_list,
                                                      'plate_third_topic_list':plate_third_topic_list,
                                                      })
    elif request.method=='GET':
        return render(request,'entertainmentlife.html')
    else:
        return HttpResponse("error")
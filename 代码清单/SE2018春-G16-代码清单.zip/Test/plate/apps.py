from django.apps import AppConfig


class PlateConfig(AppConfig):
    name = 'plate'

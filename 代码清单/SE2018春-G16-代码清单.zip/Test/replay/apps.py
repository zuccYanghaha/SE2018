from django.apps import AppConfig


class ReplayConfig(AppConfig):
    name = 'replay'

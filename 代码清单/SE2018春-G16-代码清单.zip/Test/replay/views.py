from django.shortcuts import render
from .models import bbsreplay
from django.http import HttpResponseRedirect, HttpResponse
# Create your views here.
def postreplay(request,id):
    if request.method=='POST':
        if 'posttopic' in request.POST:
            content=request.POST.get('content','')
            user=request.user
            replay=bbsreplay.objects.create(RContent=content,ReplayUser_id=user.id,ReplayTopic_id=id)
            print(100)

            return HttpResponseRedirect('/topic/detail/%s'%id)
        else:
            print(200)
            return render(request,'ReponseTopic-login.html')
    elif request.method=='GET':
        print(300)
        return render(request,'ReponseTopic-login.html')
    else:
        return HttpResponse("error")

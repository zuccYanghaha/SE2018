from .views import show_topic,post_topic,bbs_detail
from django.conf.urls import url
urlpatterns = [
    url(r'^topiclist/',show_topic,name='topiclist'),
    url(r'^detail/(\d+)/$',bbs_detail,name='topicdetail'),
    url(r'posttopic/',post_topic,name='posttopic'),
]
from django.shortcuts import render
from .models import bbstopic
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.db import  connection
from replay.models import bbsreplay

from account.models import User
# Create your views here.
def show_topic(request):
    if request.method == 'GET':
        print("text")
        bbs_topic_list=bbstopic.objects.all()
        # for l in bbs_topic_list:
        #     print(l.TTitle)
        return render(request,'topiclist.html',{'bbs_topic_list':bbs_topic_list})
    elif  request.method=='POST':
        if 'posttopic' in request.POST:
            print("tt")
            return HttpResponseRedirect(reverse('posttopic'))

def post_topic(request):
    if request.method == 'GET':
        print("GET")
        return render(request, 'posttopic.html')
    elif request.method == 'POST':
        title = request.POST.get('post_title', '')
        content = request.POST.get('post_content','')
        new_bbstopic = bbstopic.objects.create(TTitle=title,TContent=content,CreateUser_id=request.user.id)
        #       post_title =
        if 'post_topic' in request.POST:
            return HttpResponseRedirect(reverse('topiclist'))


def bbs_detail(request,bbs_id):
    if request.method=='GET':

        bbs_detail=bbstopic.objects.get(id=bbs_id)
        cursor=connection.cursor()
        cursor.execute("select UID,ReplyCreateTime,Rcontent "
                       "from replay_bbsreplay  a,account_user  b "
                       "where a.ReplayUser_id=b.id")
        row=cursor.fetchall()
        print(row)

        return render(request,'topicDetail-no.html',{'row':row,'bbs_detail':bbs_detail})
        # return render(request,'topicDetail-no.html',{'replay_list':replay_list,'bbs_detail':bbs_detail,'replay_writer':replay_writer,'howlength':howlength})
    elif request.method=='POST':
        return HttpResponse("hello,buxiangxiea")
    else:
        return HttpResponse("error")



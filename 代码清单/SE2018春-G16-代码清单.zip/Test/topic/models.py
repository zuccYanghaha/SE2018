from django.db import models
from account.models import User
from plate.models import bbsplate
# Create your models here.
class bbstopic(models.Model):#帖子model
    TTitle=models.CharField(max_length=50,unique=True,error_messages={'unqiue':"A plate with that Title already exists."}) #帖子标题
    TContent=models.TextField() #帖子内容
    TCreateTime=models.DateTimeField(auto_now_add=True) #帖子创建时间
    TAlterTime=models.DateTimeField(auto_now=True)   #帖子修改时间
    TsupportCount=models.IntegerField(default=0)  #帖子点赞数
    TdownCount=models.IntegerField(default=0) #帖子往下踩的数量
    SortOrder=models.IntegerField(default=0) #帖子状态 ，普通为0，精华=+1，置顶=+2，精华+置顶=+3
    TopicISHome=models.IntegerField(default=0) #帖子是否去首页显示（不能超过8条）
    CreateUser=models.ForeignKey(User,on_delete=models.CASCADE) #帖子创建者
    WhereClass=models.ForeignKey(bbsplate,on_delete=models.CASCADE) #帖子所在板块
    def __str__(self):
        return self.TTitle
class whothum(models.Model): #点赞表
    Thrum_up=models.IntegerField(default=0) #用户是否点赞
    Thrum_down=models.IntegerField(default=0) #用户是否踩
    Whothrum=models.ForeignKey(User,on_delete=models.CASCADE) #用户外键
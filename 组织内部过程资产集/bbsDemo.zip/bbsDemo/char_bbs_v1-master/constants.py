# !/usr/bin/env python
# coding: utf-8

CMS_SESSION_ID = 'cmsuserid'
FRONT_SESSION_ID = 'frontuserid'


# 阿里大于的  app key
ALIDAYU_APP_KEY = ''
# 阿里大于的  app secret
ALIDAYU_APP_SECRET = ''
# 阿里大于的模板签名名称
ALIDAYU_SIGN_NAME =  ''
# 阿里大于的模版的ID
ALIDAYU_TEMPLATE_CODE = ''

# 七牛云的ACCESS_key
QINIU_ACCESS_KEY = ''
# 七牛云的SECRET_Key
QINIU_SECRET_KEY = '-'

# 分页的页面的帖子数
PAGE_NUM = 15
# 登录一次加2个积分
LOGIN_UP_POINTS = 3
# 评论加一个积分
COMMENT_UP_POINTS = 2
# 点赞加一个积分
STAR_UP_POINTS = 1
# 点赞必须要有的积分
STAR_ALLOW_POINTS = 3
# 评论必须要有的积分
COMMENT_ALLOW_POINTS = 5
# 发布帖子必须要有的积分
POST_ALLOW_POINTS = 10










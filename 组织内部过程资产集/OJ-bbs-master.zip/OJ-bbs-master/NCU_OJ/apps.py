from django.apps import AppConfig


class NcuOjConfig(AppConfig):
    name = 'NCU_OJ'

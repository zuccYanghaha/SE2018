from django.shortcuts import render,get_object_or_404
from .models import Post,Category
import markdown
import pygments

# Create your views here.
def index(request):
    post_list=Post.objects.all()
    return render(request,'NCU_OJ/index.html',{'post_list':post_list})
def detail(request,pk):
    post=get_object_or_404(Post,pk=pk)
    post.increase_views()
    post.text=markdown.markdown(post.text,
                                extensions=[
                                    'markdown.extensions.extra',
                                    'markdown.extensions.codehilite',
                                    'markdown.extensions.toc'
                                ])
    return render(request,'NCU_OJ/detail.html',{'post':post})


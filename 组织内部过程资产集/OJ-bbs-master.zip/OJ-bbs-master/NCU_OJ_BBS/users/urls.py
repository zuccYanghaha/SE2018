from django.conf.urls import url
from . import views

app_name = 'users'


urlpatterns = [
    url(r'^register/$', views.register, name='register'),
<<<<<<< HEAD
=======
    url(r'^index/$', views.index, name='index'),

>>>>>>> fc14474d436cf911e3fd6a8f8af044d30149ebb4
]
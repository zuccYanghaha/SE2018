from django.db import models
from users.models import User
from django.urls import reverse
import django.utils.timezone as timezone
import markdown
import pygments


class Category(models.Model):
    category = models.CharField(max_length=20, null=True, blank=True)

    def __str__(self):
        return self.category


class Tag(models.Model):
    tag = models.CharField(max_length=20, null=True, blank=True)

    def __str__(self):
        return self.tag


class Post(models.Model):
    title = models.CharField(max_length=30)
    text = models.TextField()
    created_time = models.DateField(default=timezone.now)
    category = models.ForeignKey(Category)
    tag = models.ManyToManyField(Tag)
    author = models.ForeignKey(User)
    views = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('NCU_OJ:detail', kwargs={'pk': self.pk})

    def increase_views(self):
        self.views += 1
        self.save(update_fields=['views'])

    class Meta:
        ordering = ['-created_time']




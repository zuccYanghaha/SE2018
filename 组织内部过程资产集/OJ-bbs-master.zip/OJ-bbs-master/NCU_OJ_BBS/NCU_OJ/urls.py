from django.conf.urls import url,include
from django.contrib import admin
from NCU_OJ import views


app_name = 'NCU_OJ'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^detail/(?P<pk>[0-9]+)/$', views.detail, name='detail')
]
